package com.nisum.userscreation.persistence.models;

import lombok.Data;
import javax.persistence.*;

@Entity
@Table(name = "telefono")
@Data
public class PhoneModel {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    private Long id;

    @Column(nullable = false)
    private String number;

    @Column(nullable = false)
    private String cityCode;

    @Column(nullable = false)
    private String countryCode;
}
