package com.nisum.userscreation.persistence.repositories;

import com.nisum.userscreation.persistence.models.PhoneModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PhoneRepository extends JpaRepository<PhoneModel, Long> {
}
