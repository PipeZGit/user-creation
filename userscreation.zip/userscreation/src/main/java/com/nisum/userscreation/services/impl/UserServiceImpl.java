package com.nisum.userscreation.services.impl;

import com.nisum.userscreation.exceptions.ToDoExceptions;
import com.nisum.userscreation.mapper.UserInDTOToUser;
import com.nisum.userscreation.persistence.models.PhoneModel;
import com.nisum.userscreation.persistence.models.UserModel;
import com.nisum.userscreation.persistence.repositories.PhoneRepository;
import com.nisum.userscreation.persistence.repositories.UserRepository;
import com.nisum.userscreation.services.PhoneService;
import com.nisum.userscreation.services.UserService;
import com.nisum.userscreation.services.dto.UserInDTO;
import com.nisum.userscreation.util.Constantes;
import com.nisum.userscreation.util.Utils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final PhoneRepository phoneRepository;
    private final PhoneService phoneService;
    private final UserInDTOToUser mapper;

    public UserServiceImpl(UserRepository userRepository, UserInDTOToUser mapper, PhoneRepository phoneRepository, PhoneService phoneService) {
        this.userRepository = userRepository;
        this.mapper = mapper;
        this.phoneRepository = phoneRepository;
        this.phoneService = phoneService;
    }

    public UserModel createUser(UserInDTO userInDTO) {
        UserModel userModel = mapper.map(userInDTO);
        List<PhoneModel> newPhones = this.phoneService.createPhone(userModel);
        userModel.setPhones(newPhones);
        return this.userRepository.save(userModel);
    }

    public List<UserModel> findAll() {
        if (this.userRepository.findAll().isEmpty()) {
            throw new ToDoExceptions(Constantes.SIN_DATOS, HttpStatus.NO_CONTENT);
        }
        return this.userRepository.findAll();
    }

    public List<UserModel> findAllByEmail(String email) {
        if (this.userRepository.findAllByEmail(email).isEmpty()) {
            throw new ToDoExceptions(Constantes.SIN_DATOS, HttpStatus.NO_CONTENT);
        }
        return this.userRepository.findAllByEmail(email);
    }

    public boolean existsUserModelByEmail(String email) {
        return this.userRepository.existsUserModelByEmail(email);
    }

    public boolean isValidEmail(String email) {
        return Utils.validarCorreo(email);
    }

    public boolean isValidPassword(String password) {
        return Utils.validarPassword(password);
    }

    @Transactional
    public void updateUserAsInactive(Long id) {
        Optional<UserModel> optionalUser = this.userRepository.findById(id);
        if (optionalUser.isEmpty()) {
            throw new ToDoExceptions(Constantes.USUARIO_NO_ENCONTRADO, HttpStatus.NOT_FOUND);
        }
        this.userRepository.markUserAsInactive(id);
    }

    public String getRegex(String param3) {
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{"+ param3 + ",}$";
        return regex;
    }
}
