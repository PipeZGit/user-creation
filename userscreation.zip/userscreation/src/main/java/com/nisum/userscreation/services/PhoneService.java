package com.nisum.userscreation.services;

import com.nisum.userscreation.persistence.models.PhoneModel;
import com.nisum.userscreation.persistence.models.UserModel;
import java.util.List;

public interface PhoneService {
    List<PhoneModel> createPhone(UserModel usrModel);
}
