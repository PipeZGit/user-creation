package com.nisum.userscreation.mapper;

import com.nisum.userscreation.persistence.models.UserModel;
import com.nisum.userscreation.services.dto.UserInDTO;
import com.nisum.userscreation.util.Utils;
import org.springframework.stereotype.Component;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

@Component
public class UserInDTOToUser implements IMapper<UserInDTO, UserModel>{

    @Override
    public UserModel map(UserInDTO in) {

        LocalDateTime localDateTime = LocalDateTime.now();
        Date date = Date.from(localDateTime.atZone(ZoneId.systemDefault()).toInstant());

        UserModel userModel = new UserModel();
        userModel.setId(Utils.generarUUIDLong());
        userModel.setName(in.getName());
        userModel.setEmail(in.getEmail());
        userModel.setPassword(in.getPassword());
        userModel.setCreated(date);
        userModel.setModified(date);
        userModel.setLastLogin(date);
        userModel.setToken(Utils.generarUUIDString());
        userModel.setPhones(in.getPhones());
        userModel.setActive(true);

        return userModel;
    }
}
