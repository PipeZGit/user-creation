package com.nisum.userscreation.controllers;

import com.nisum.userscreation.exceptions.ToDoExceptions;
import com.nisum.userscreation.persistence.models.UserModel;
import com.nisum.userscreation.services.UserService;
import com.nisum.userscreation.services.impl.UserServiceImpl;
import com.nisum.userscreation.services.dto.UserInDTO;
import com.nisum.userscreation.util.Constantes;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/usuarios")
public class UserController {
    private final UserService userService;

    public UserController(UserServiceImpl userServiceImpl) {
        this.userService = userServiceImpl;
    }

    /**
     * Permite la creación de usuarios
     *
     * @param userInDTO contiene el request
     * @return UserModel
     */
    @ApiOperation(value = "Permite realizar la creación de usuarios")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "El proceso fue exitoso"),
            @ApiResponse(code = 208, message = "Dato ya registrado"),
            @ApiResponse(code = 406, message = "El correo y/o la contraseña no cumplen con el formato requerido")
    })
    @PostMapping("/createUser")
    public UserModel createUser(@RequestBody UserInDTO userInDTO) {
        if (this.userService.existsUserModelByEmail(userInDTO.getEmail())) {
            throw new ToDoExceptions(Constantes.CORREO_REGISTRADO, HttpStatus.ALREADY_REPORTED);
        }
        if (!this.userService.isValidEmail(userInDTO.getEmail())) {
            throw new ToDoExceptions(Constantes.EMAIL_INVALIDO, HttpStatus.NOT_ACCEPTABLE);
        }
        if (!this.userService.isValidPassword(userInDTO.getPassword())) {
            throw new ToDoExceptions(Constantes.PASSWORD_INVALIDO, HttpStatus.NOT_ACCEPTABLE);
        }
        return this.userService.createUser(userInDTO);
    }

    /**
     * Permite la búsqueda de usuarios
     *
     * @param
     * @return List<UserModel>
     */
    @ApiOperation(value = "Permite realizar la búsqueda de todos los usuarios")
    @GetMapping()
    public List<UserModel> findAll() {
        return this.userService.findAll();
    }

    /**
     * Permite la búsqueda de usuarios por email
     *
     * @param email
     * @return List<UserModel>
     */
    @ApiOperation(value = "Permite realizar la búsqueda de todos los usuarios por Email")
    @GetMapping("/email/{email}")
    public List<UserModel> findAllByEmail(@PathVariable(Constantes.EMAIL) String email) {
        return this.userService.findAllByEmail(email);
    }

    /**
     * Permite inactivar un usuario
     *
     * @param id
     * @return ResponseEntity<Void>
     */
    @ApiOperation(value = "Permite realizar la inactivación de un usario a traves de su id")
    @PatchMapping("/mark_user_as_inactive/{id}")
    public ResponseEntity<Void> updateUserAsInactive(@PathVariable(Constantes.ID) Long id) {
        this.userService.updateUserAsInactive(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/generate")
    public String generateRegex(@RequestParam("param1") String param1, @RequestParam("param2") String param2, @RequestParam("param3") String param3) {
        return this.userService.getRegex(param3);
    }
}
