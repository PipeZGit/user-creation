package com.nisum.userscreation.util;

import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {
    public static boolean validarCorreo(String correo) {
        String regex = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z]{2,}\\b";
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(correo);
        return matcher.matches();
    }
    public static boolean validarPassword(String password) {
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }
    public static String generarUUIDString() {
        return UUID.randomUUID().toString();
    }
    public static Long generarUUIDLong() {
        UUID uuid = UUID.randomUUID();
        long uuidLong = uuid.getMostSignificantBits() ^ uuid.getLeastSignificantBits();
        return (Long) uuidLong;
    }
}
