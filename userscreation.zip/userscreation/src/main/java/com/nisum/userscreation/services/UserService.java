package com.nisum.userscreation.services;

import com.nisum.userscreation.persistence.models.UserModel;
import com.nisum.userscreation.services.dto.UserInDTO;
import java.util.List;

public interface UserService {
    UserModel createUser(UserInDTO userInDTO);
    List<UserModel> findAll();
    List<UserModel> findAllByEmail(String email);
    boolean existsUserModelByEmail(String email);
    boolean isValidEmail(String email);
    boolean isValidPassword(String password);
    void updateUserAsInactive(Long id);
    String getRegex(String param3);
}
