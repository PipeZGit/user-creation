package com.nisum.userscreation.services.dto;

import com.nisum.userscreation.persistence.models.PhoneModel;
import lombok.Data;
import java.util.List;

@Data
public class UserInDTO {

    private String name;
    public String email;
    private String password;
    private List<PhoneModel> phones;
}
