package com.nisum.userscreation.services.impl;

import com.nisum.userscreation.persistence.models.PhoneModel;
import com.nisum.userscreation.persistence.models.UserModel;
import com.nisum.userscreation.persistence.repositories.PhoneRepository;
import com.nisum.userscreation.services.PhoneService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class PhoneServiceImpl implements PhoneService {

    private final PhoneRepository phoneRepository;

    public PhoneServiceImpl(PhoneRepository phoneRepository) {
        this.phoneRepository = phoneRepository;
    }

    public List<PhoneModel> createPhone(UserModel userModel) {
        List<PhoneModel> phones = userModel.getPhones();
        List<PhoneModel> newPhones = phones.stream().map(item -> {
            PhoneModel phoneModel = new PhoneModel();
            phoneModel.setId(item.getId());
            phoneModel.setNumber(item.getNumber());
            phoneModel.setCityCode(item.getCityCode());
            phoneModel.setCountryCode(item.getCountryCode());
            return this.phoneRepository.save(phoneModel);
        }).collect(Collectors.toList());
        return newPhones;
    }
}
