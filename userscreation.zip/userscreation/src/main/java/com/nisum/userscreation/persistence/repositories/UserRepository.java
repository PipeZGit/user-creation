package com.nisum.userscreation.persistence.repositories;

import com.nisum.userscreation.persistence.models.UserModel;
import com.nisum.userscreation.util.Constantes;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface UserRepository extends JpaRepository<UserModel, Long> {

    public List<UserModel> findAllByEmail(String email);
    public boolean existsUserModelByEmail(String email);
    @Modifying
    @Query(value = "UPDATE USUARIO SET IS_ACTIVE = false, MODIFIED = CURRENT_TIMESTAMP WHERE ID = :id", nativeQuery = true)
    public void markUserAsInactive(@Param(Constantes.ID) Long id);
}