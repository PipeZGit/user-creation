package com.nisum.userscreation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoCreacionDeUsuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoCreacionDeUsuariosApplication.class, args);
	}

}
