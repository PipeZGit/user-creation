package com.nisum.userscreation.util;

public class Constantes {

    public static final String CORREO_REGISTRADO = "El correo ya esta registrado";
    public static final String ID = "id";
    public static final String EMAIL = "email";
    public static final String USUARIO_NO_ENCONTRADO = "Usuario no encontrado";
    public static final String EMAIL_INVALIDO = "El correo no tiene un formato válido";
    public static final String PASSWORD_INVALIDO = "La contraseña no tiene una estructura válida";
    public static final String SIN_DATOS = "No hay Datos";
}
