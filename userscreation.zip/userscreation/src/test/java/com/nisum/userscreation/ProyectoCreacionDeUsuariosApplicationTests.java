package com.nisum.userscreation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCreacionDeUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
